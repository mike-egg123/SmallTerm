<template>
    <router-view></router-view>
</template>
<script>
  export default {
    name: 'Team'
  }
</script>

<style scoped>

</style>
