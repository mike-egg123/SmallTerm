<template>
  <div>
    <el-row>
      <el-col :span="3" v-for="(currentItem, index) in currentList" :key="index" :offset="index%6==0?0:1">
        <el-card :body-style="{ padding: '0px' }" shadow="hover" style="margin-bottom: 10px; -webkit-transition-duration:0.3s; -webkit-transition-timing-function:linear; -webkit-transition-delay:0.01s;">
          <CurrentArticle :currentItem="currentItem"/>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>
<script>
  import {mapState,mapActions} from 'vuex'
  import CurrentArticle from '../../components/CurrentArticle'
  export default {
    name: 'Recent',
    mounted () {
      this.recordCurrentList()
    },

    computed:{
      ...mapState(['currentList'])
    },
    methods:{
      ...mapActions(['getCurrentList','recordCurrentList']),
    },
    components:{CurrentArticle}
  }
</script>

<style scoped>

</style>
