<template>
  <div>
    Person
  </div>
</template>

<script>
export default {
  name: 'Person'
}
</script>

<style scoped lang="stylus" rel="stylesheet">

</style>
