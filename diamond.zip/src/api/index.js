/*
与后台交互模块
 */
import ajax from './ajax'
/**
 * 账号密码登录
 */
const MY_URL='http://182.92.239.145'
export const reqPwdLogin = (username, password) => ajax('/apis/user/login', {
  username,password
}, 'POST')

/*
获取用户登录状态
 */
export const reqGetStatus = () => ajax('/apis/user/getstatus' )

/*
用户注册
 */
export const reqPwdRegister = (username ,email ,password) => ajax('/apis/user/register',{
  username ,email ,password
},'POST')

/*
用户退出
 */
export const reqPwdLogout = () => ajax('/apis/user/logout')

/*
修改个人信息
 */
export const reqChange = (formData) => ajax('/apis/personality/change',formData,'POST')

/*
查看个人信息
 */
export const reqGet = (formData) => ajax('/apis/personality/get',formData,'POST')

/*
创建在线文档
 */
export const reqCreate = (content) => ajax('/apis/article/create',{content},'POST')

/*
查询权限
 */
export const reqGetPermission = (userid,articleid) => ajax('apis/workplace/getpermission',{
  userid,articleid
},'POST')

/*
查询权限设定
 */
export const reqGetPermissionSetting = (userid,articleid) => ajax('apis/workplace/getpermissionsetting',{
  userid,articleid
},'POST')

/*
修改权限
 */
export const reqSetPermission = (userid,state,articleid,teamlist) => ajax('apis/workplace/setpermission',{
  userid,state,articleid,teamlist
},'POST')

/*
获取加入的所有团队
 */
export const reqGetAllTeam = (userid) => ajax('apis/workplace/myallteam',{userid},'POST')

/*
查看文档
 */
export const reqFetch = (articleid,userid) => ajax('/apis/article/get',{
  articleid,userid
},'POST')

/*
修改文档(removed "userid")
 */
export const reqUpdate = (articleid,title,content,permission) => ajax('/apis/article/updateYi',{
  articleid,title,content,permission
},'POST')

/*
  删除文档
 */
export const reqDeleteArticle = (articleid) => ajax('/apis/article/delete',{articleid},'POST')

/*
获取评论
 */
export const reqGetComment = (articleid) => ajax('/apis/comment/getbyarticleid',{
  articleid
},'POST')

/*
发表评论
 */
export const reqAddComment = (articleid,userid,content) => ajax('apis/comment/post',{
  articleid,userid,content
},'POST')

/*
评论时向作者发消息
 */
export const reqCommentMessage = (articleid,userid) => ajax('apis/message/commentmessage',{
  articleid,userid
},'POST')

/*
释放互斥锁
 */
export const reqReleaseLock = (articleid) => ajax('apis/article/releaselock',{
  articleid
},'POST')

/*
恢复文档
 */
export const reqRecoverArticle = (articleid) => ajax('/apis/article/recover',{articleid},'POST')

/*
文档收藏与否
islike  0取消收藏 1收藏
 */
export const reqLikeornotArticle = (userid,articleid,islike) => ajax('/apis/article/likeornot',{
  userid,articleid,islike
},'POST')

/*
获取最近浏览的文档
 */
export const reqGetRecentArticle = (userid) => ajax('/apis/article/getrecentwatch',{userid},'POST')

/*
获取最近浏览的文档（异步）
 */
export const reqGetRecentArticleYi = () =>ajax('/apis/article/getrecentwatchYi',{},'POST')

/*
获取所有收藏
 */
export const reqGetAllLikesArticle = (userid) => ajax('/apis/article/getalllikes',{userid},'POST')

/*
获取所有收藏（异步）
 */
export const reqGetAllLikesArticleYi = () => ajax('/apis/article/getalllikesYi',{},'POST')

/*
获取所有创建
 */
export const reqGetAllCreateArticle = (userid) => ajax('/apis/article/getallcreations',{userid},'POST')

/*
获取所有创建（异步）
 */
export const reqGetAllCreateArticleYi = () =>ajax('/apis/article/getallcreationsYi',{},'POST')

/*
获取回收站文档
 */
export const reqGetGarbageArticle = (userid) => ajax('/apis/article/getallcreationsingarbage',{userid},'POST')

/*
获取回收站文档
 */
export const reqGetGarbageArticleYi = () => ajax('/apis/article/getallcreationsingarbageYi',{},'POST')

/*
改变文档修改状态
 */
export const reqUpdatingcodeArticle = (updatingcode,articleid) => ajax('/apis/article/updatingcodechange',{
  updatingcode,articleid
},'POST')

/*
获取登录验证码
 */
export const reqGetValidCode = () => ajax('/apis/user/getvalidcode','','POST')

/*
创建团队
 */
export const reqCreateTeam = (teamname,userid) => ajax('/apis/workplace/createteam', {teamname,userid},'POST')

/*
加入团队
 */
export const reqJoinTeam = (teamid,userid) => ajax('/apis/workplace/jointeam',{teamid,userid},'POST')

/*
退出团队
 */
export const reqExitTeam = (userid,teamid) => ajax('/apis/workplace/exitteam',{userid,teamid},'POST')

/*
解散团队
 */
export const reqDisband = (teamid) => ajax('/apis/workplace/disband',{teamid},'POST')

/*
获取全部加入的团队
 */
export const reqMyJoinTeam = (userid) => ajax('/apis/workplace/myjointeam',{userid},'POST')

/*
获取全部加入的团队（异步）
 */
export const reqMyJoinTeamYi = () => ajax('/apis/workplace/myjointeamYi',{},'POST')

/*
获取某个团队的所有成员
 */
export const reqGetTeamMember = (teamid) => ajax('/apis/workplace/getteammember',{teamid},'POST')

/*
获取某个团队的所有文档
 */
export const reqGetAllArticles = (teamid) => ajax('/apis/workplace/getallarticles',{teamid},'POST')

/*
获取创建的所有团队
 */
export const reqMyCreateTeam = (userid) => ajax('/apis/workplace/mycreateteam',{userid},'POST')

/*
获取创建的所有团队（异步）
 */
export const reqMyCreateTeamYi = () => ajax('/apis/workplace/mycreateteamYi',{},'POST')

/*
获取团队信息
 */
export const reqTeamInfo = (teamid) => ajax('/apis/workplace/getteaminfo',{teamid},'POST')

/*
全局搜索用户
 */
export const reqSearchUser = (keyword) => ajax('/apis/search/users',{keyword},'POST')

/*
全局搜索文档
 */
export const reqSearchDoc = (userid,keyword) => ajax('/apis/workplace/searchdoc',{userid,keyword},'POST')

/*
全局搜索团队
 */
export const reqSearchTeam = (userid,keyword) => ajax('/apis/workplace/searchteam',{userid,keyword},'POST')

/*
踢人
 */
export const reqOutTeam = (userid,teamid) => ajax('/apis/workplace/outteam',{userid,teamid},'POST')

// ================================消息通知===========================

/*
查找邀请的用户消息
 */
export const reqSearchInviteUser = (userid,teamid,username) => ajax('/apis/message/getuser',{userid,teamid,username},'POST')

/*
邀请用户加入团队消息
 */
export const reqInviteUser = (teamid,inviteduserid,userid) => ajax('/apis/message/invite',{teamid,inviteduserid,userid},'POST')

/*
接收团队消息通知
 */
export const reqGetTeamMessage = (userid) => ajax('/apis/message/getteammessage',{userid},'POST')

/*
接收评论消息通知
 */
export const reqGetCommentMessage = (userid) => ajax('/apis/message/getcommentmessage',{userid},'POST')

/*
删除评论消息通知
 */
export const reqSolveCommentMessage = (messageid) => ajax('/apis/message/solvecommentmessage',{messageid},'POST')

/*
删除团队消息通知
 */
export const reqSolveTeamMessage = (messageid) => ajax('/apis/message/solveteammessage',{messageid},'POST')

/*
退出团队消息通知(给团队创建者发送消息通知)
 */
export const reqExitTeamMessage = (userid,teamid) => ajax('/apis/message/exitteammessage',{userid,teamid},'POST')

/*
踢人消息通知(给被踢用户发送消息通知)
 */
export const reqOutTeamMessage = (teamid,outuserid,userid) => ajax('/apis/message/outteammessage',{
  teamid,outuserid,userid
},'POST')

/*
同意邀请消息通知(发给团队创建者)
 */
export const reqAgreeInvitation = (teamid,inviteuserid,userid) => ajax('/apis/message/agreeinvitation',{
  teamid,inviteuserid,userid
},'POST')

/*
拒绝邀请消息通知(发给团队创建者)
 */
export const reqRefuseInvitation = (teamid,inviteuserid,userid) => ajax('/apis/message/refuseinvitation',{
  teamid,inviteuserid,userid
},'POST')

/*
申请加入团队(发给团队创建者)
 */
export const reqApply = (teamid,userid) => ajax('/apis/message/apply',{teamid,userid},'POST')

/*
同意申请消息通知(发给申请用户)
 */
export const reqAgreeApply = (teamid,applyuserid,userid) => ajax('/apis/message/agreeapply',{
  teamid,applyuserid,userid
},'POST')

/*
拒绝申请消息通知(发给申请用户)
 */
export const reqRefuseApply = (teamid,applyuserid,userid) => ajax('/apis/message/refuseapply',{
  teamid,applyuserid,userid
},'POST')

/*
发送私信
 */
export const reqSendPrivateMessage = (userid,message,touserid) => ajax('/apis/chat/sendmessage',{
  userid,message,touserid
},'POST')

/*
接收私信
 */
export const reqGetPrivateMessage = (userid) => ajax('/apis/chat/getmessage',{userid},'POST')

/*
删除私信
 */
export const reqDeletePrivateMessage = (messageid) => ajax('/apis/chat/deletemessage',{messageid},'POST')
